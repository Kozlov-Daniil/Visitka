import 'dart:ui';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(MaterialApp(
  home: UserPanel(),
));

class UserPanel extends StatelessWidget {
  const UserPanel({Key? key}) : super(key: key);
  
  @override 
  Widget build(BuildContext context)
  {
    var linkText;
    return Scaffold(
      backgroundColor: Colors.orange.shade700,
      appBar: AppBar(
        title: Text('Визитка'),
        centerTitle: true,
        backgroundColor: Colors.black,
      ),
      body: SafeArea(
        child: Row (
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
        Column(
        
          children:  [
            Padding(padding: EdgeInsets.only(top: 20),),
            CircleAvatar(
              backgroundImage: AssetImage('assets/1.jpg'),
              radius: 60,
            ),
            Padding(padding: EdgeInsets.only(top: 20),),
            Text('Козлов Даниил Анатольевич', style: TextStyle(
            fontSize: 25,
            color: Colors.black87
            ),),
            Padding(padding: EdgeInsets.only(top: 10),),
            Text('Начинающий Web-разработчик', style: TextStyle(
              fontSize: 18,
              color: Colors.black54
            ),),
            Padding(padding: EdgeInsets.only(top: 50),),
            Text(
              'Привет, я - начинающий web-разработчик.На этой странице содержится информация, необходимая для того чтобы связаться со мной.', style: TextStyle(
                fontSize: 17,
                color: Colors.black87,
              ),
            ),
            Padding(padding: EdgeInsets.only(top:5),),
            Text('Ниже предоставлена следующая информация: адрес, электронная почта и номер телефона:', style: TextStyle(
              fontSize: 17,
              color: Colors.black87,
            ),),
            Padding(padding: EdgeInsets.only(top: 70)),
            Row(
              children: [
                Column(
                  children:[
                
                Text('isip_d.a.kozlov@mpt.ru', style: TextStyle(
                  fontSize: 18,
                  color: Colors.white60,
                ),),
                Icon(Icons.email, size: 25, color: Colors.white60,),]),
                Padding(padding: EdgeInsets.only(right: 300,)),
                Column(
                  children:[
                Text('Симферопольский бульвар д.27', style: TextStyle(
                  fontSize: 18,
                  color: Colors.white60,
                ),),
                Icon(Icons.home, size: 30, color: Colors.white60,),]),
                Padding(padding: EdgeInsets.only(left: 350,)),
                Column(
                  children:[
                
                Text('7-(902)-722-02-28', style: TextStyle(
                  fontSize: 18,
                  color: Colors.white60,
                ),),
               
                Icon(Icons.phone_android, size: 25, color: Colors.white,),]
                ),
                
              ],
            ),
            Padding(padding: EdgeInsets.only(top: 70)),
           
            Row(
          
                  children: [
                    
                    Image.asset('assets/vk.png',  width: 70,),
                    Padding(padding: EdgeInsets.only(right: 250)),
                    Image.asset('assets/git.png',  width: 70,),
                    Padding(padding: EdgeInsets.only(left: 250)),
                    Image.asset('assets/zen.png',  width: 90,),
                  ],
                ),
                Row(
                  children: [
                     RichText(
          text: TextSpan(
            children: [
              TextSpan(
              
              ),
              TextSpan(
                style: linkText,
                 text: "ВК", 
                  recognizer: TapGestureRecognizer()..onTap =  () async{
                    var url = "https://vk.com/eagle_talibal";
                        if (await canLaunch(url)) {
                          await launch(url);
                        } else {
                          throw 'Could not launch $url';
                        }
                  }
              ),
            ]
        )),
        Padding(padding: EdgeInsets.only(right: 305),),
         RichText(
          text: TextSpan(
            children: [
              TextSpan(
                
              ),
              TextSpan(
                style: linkText,
                 text: "GIT",
                  recognizer: TapGestureRecognizer()..onTap =  () async{
                    var url = "https://github.com/Kozlov-Daniil";
                        if (await canLaunch(url)) {
                          await launch(url);
                        } else {
                          throw 'Could not launch $url';
                        }
                  }
              ),
            ]
        )),
        Padding(padding: EdgeInsets.only(left: 305),),
         RichText(
          text: TextSpan(
            children: [
              TextSpan(
                
              ),
              TextSpan(
                style: linkText,
                 text: "Zen", 
                 
                  recognizer: TapGestureRecognizer()..onTap =  () async{
                    var url = "https://zen.yandex.ru/id/5f13623eaeb3d4194b7f8e22";
                        if (await canLaunch(url)) {
                          await launch(url);
                        } else {
                          throw 'Could not launch $url';
                        }
                  }
              ),
            ]
        )),
                  ],
                )
          ],
        ),
        ],
        )
      ),
    );

    
   
      
    
  }
}
